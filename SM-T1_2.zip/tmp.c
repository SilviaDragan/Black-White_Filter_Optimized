#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <string.h>
#include "utils.h"
#include <chrono>
#include <time.h>
#include <iostream>
#include "mpi.h"

#define MASTER 0

using namespace std;


void luDecomposition(float **matrix, float **lower, float **upper, int n, int rank, int num_procs) {

	for (int i = 0; i < n; i++) {
        int start = rank * ((double) (n - i)) / num_procs;
        int end = min((int)((rank + 1) * ((double) (n - i)) / num_procs), n - i);
		for (int k = i + start; k < i + end; k++) {
			float sum = 0.0;
			for (int j = 0; j < i; j++)
				sum += (lower[i][j] * upper[j][k]);

			upper[i][k] = matrix[i][k] - sum;
		}

        if (rank == MASTER) {
            for (int j = 1; j < num_procs; j++) {
                int proc_start = j * ((double) (n - i)) / num_procs;
                int proc_end = min((int)((j + 1) * ((double) (n - i)) / num_procs), n - i);
                MPI_Recv(&(upper[i][proc_start + i]), proc_end - proc_start, MPI_FLOAT, j, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            }
            for (int j = 1; j < num_procs; j++) {
                MPI_Send(&(upper[i][0]), n, MPI_FLOAT, j, 0, MPI_COMM_WORLD);
            }
            
        } else {
            MPI_Send(&(upper[i][i + start]), end - start, MPI_FLOAT, MASTER, 0, MPI_COMM_WORLD);
            MPI_Recv(&(upper[i][0]), n, MPI_FLOAT, MASTER, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }

        float *column = (float *) calloc(n, sizeof(float));
		for (int k = i + start; k < i + end; k++) {
			if (i == k) {
				lower[i][i] = 1;
			} else {
				float sum = 0;
				for (int j = 0; j < i; j++)
					sum += (lower[k][j] * upper[j][i]);

				lower[k][i] = (matrix[k][i] - sum) / upper[i][i];
			}
            column[k - start - i] = lower[k][i];
		}

        float *full_column = (float *) calloc(n, sizeof(float));
        if (rank == MASTER) {
            for (int j = 1; j < num_procs; j++) {
                int proc_start = j * ((double) (n - i)) / num_procs;
                int proc_end = min((int)((j + 1) * ((double) (n - i)) / num_procs), n - i);
                MPI_Recv(column, proc_end - proc_start, MPI_FLOAT, j, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
                for (int k = i + proc_start; k < i + proc_end; k++)
                    lower[k][i] = column[k - proc_start - i];
            }
            for (int j = 0; j < n; j++)
                full_column[j] = lower[j][i];
            for (int j = 1; j < num_procs; j++) {
                MPI_Send(full_column, n, MPI_FLOAT, j, 0, MPI_COMM_WORLD);
            }
            
        } else {
            MPI_Send(column, end - start, MPI_FLOAT, MASTER, 0, MPI_COMM_WORLD);
            MPI_Recv(full_column, n, MPI_FLOAT, MASTER, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            for (int j = 0; j < n; j++)
                lower[j][i] = full_column[j];
        }
	}
}

int main(int argc, char **argv)
{
    int rank, num_procs;
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &num_procs);

	if (argc < 2)
		throw_error(strdup("Insufficient arguments!"));

    float **matrix;
    float **lower;
    float **upper;
    int elements = atoi(argv[1]);
    matrix = allocate_square_matrix(elements);
    lower = allocate_square_matrix(elements);
    upper = allocate_square_matrix(elements);
    if (rank == MASTER) {
        srand(42);

	    initialize_random_matrix(matrix, elements);
        for (int i = 1; i < num_procs; i++) {
            for (int j = 0; j < elements; j++)
                MPI_Send(&(matrix[j][0]), elements, MPI_FLOAT, i, 0, MPI_COMM_WORLD);
        }
    } else {
        for (int j = 0; j < elements; j++)
            MPI_Recv(&(matrix[j][0]), elements, MPI_FLOAT, MASTER, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    }

    clock_t t;
    if (rank == MASTER) {
        t = clock();
    }

    luDecomposition(matrix, lower, upper, elements, rank, num_procs);

    if (rank == MASTER) {
        t = clock() - t;

        // cout << "Lower Triangular" << endl;
        // print_matrix(lower, elements);

        // cout << "Upper Triangular" << endl;
        // print_matrix(upper, elements);

        double time_taken = ((double)t)/CLOCKS_PER_SEC; 

        cout << elements << " " << time_taken << endl;
    }
    MPI_Finalize();
	return 0;
}

